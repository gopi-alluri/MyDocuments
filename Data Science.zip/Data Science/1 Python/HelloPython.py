# Hello Python Program
print('Hello Python')
