# -*- coding: utf-8 -*-
"""
Created on Thu Jun 13 11:38:35 2019

@author: AGKR
"""

import pandas as pd, numpy as np

# create a data frame
df = pd.DataFrame(np.arange(12).reshape(3,4), columns=['A', 'B', 'C', 'D'])

# =============================================================================
# DataFrame.drop(labels=None, axis=0, index=None, columns=None, level=None, inplace=False, errors='raise')[source]
# Drop specified labels from rows or columns.
# 
# Remove rows or columns by specifying label names and corresponding axis, or by specifying directly index or column names
# =============================================================================

# ** DataFrame.drop(labels=None, axis=0, index=None, columns=None, inplace=False)

# remove columns by specifying column names
df.drop(columns=['C','B'])

# remove columns by specifying label names and corresponding axis
df.drop(['A','B'], axis=1)

# remove rows by specifiying index
df.drop([0,1])

df.drop(index=[0,1], axis =0)

df.drop(index=[0,1], columns=['C','B'])

# inplace : bool, default False, If True, do operation inplace and return None
df.drop(['A','B'], axis=1, inplace=True)

# =============================================================================
# pandas.concat(objs, axis=0, join='outer', join_axes=None, ignore_index=False, keys=None, levels=None, names=None, verify_integrity=False, sort=None, copy=True)[source]
# Concatenate pandas objects along a particular axis with optional set logic along the other axes.
# =============================================================================

# ** pandas.concat(objs, axis=0, ignore_index=False, sort=None)
df1 = pd.DataFrame([['a', 1], ['b', 2]], columns=['letter', 'number'])

df2 = pd.DataFrame([['c', 3], ['d', 4]], columns=['letter', 'number'])

# Combine two DataFrame objects with identical columns
df3 = pd.concat([df1, df2])

df4 = pd.concat([df1, df2], ignore_index=True)

# =============================================================================
# Combine DataFrame objects with overlapping columns and return everything. 
# Columns outside the intersection will be filled with NaN values.
# =============================================================================

df5 = pd.DataFrame([['c', 3, 'cat'], ['d', 4, 'dog']], columns=['letter', 'number', 'animal'])

df6 = pd.concat([df1, df5], sort=False)

df7 = pd.concat([df1, df5], sort=True)

# =============================================================================
# Combine DataFrame objects horizontally along the x axis by passing in axis=1
# =============================================================================

df8 = pd.DataFrame([['bird', 'polly'], ['monkey', 'george'], ['man', 'john']],columns=['animal', 'name'])

pd.concat([df1, df8], axis=1)

ser = pd.Series([np.NaN, 2, pd.NaT, '', None, 'I stay'])
ser.isnull().sum()
ser.isna()

df1 = pd.DataFrame([['a', 1], ['a', ''],[np.NaN, 2],['c', None],['d', pd.NaT]], columns=['letter', 'number'])
null_idx = df1.isna().sum()
df1.loc[null_idx, 'number'] = 0

